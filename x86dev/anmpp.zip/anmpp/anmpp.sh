fdir=/mnt/sdcard/anmpp
bbx=/system/xbin/busybox
$bbx echo "Install Anmpp ...."
$bbx tar -jxf $fdir/anmpp.tar.bz2 -C /data/data
$bbx echo "All Installation Complete ."
